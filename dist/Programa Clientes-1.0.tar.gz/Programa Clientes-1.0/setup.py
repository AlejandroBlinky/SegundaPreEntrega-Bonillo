from setuptools import setup

setup(
    name="Programa Clientes",
    version="1.00",
    description="Programa para modelamiento de clientes y login",
    author="Marcos Alejandro Bonillo",
    author_email="bonillo_alejandro@outlook.es",
    packages=["paquete1"]
)